# David Rapp Application Pack

Created 2026-06-18.

This folder contains four current job-search lanes:

1. Security systems / low-voltage / field technician
2. PRS / behavioral health support
3. HVAC helper / installation apprentice / field support
4. General all-purpose operations / warehouse / field support

Use the PDF files for upload. Keep the DOCX files for edits. Put the Markdown files into Obsidian.

Suggested Obsidian folder:
09-PROMPTS/Applications/Current-Resumes/

Important guardrails:
- Do not invent credentials, dates, tools, clinical duties, licenses, or supervisory authority.
- The HVAC version mentions approximate prior HVAC support without inventing exact dates.
- The PRS version uses the verified PRS license APS.006470 and OhioMHAS training ID MON554.
- The security version uses the Pro-Techs/family-business background carefully and does not claim a low-voltage license.
