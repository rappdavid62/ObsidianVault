---
type: job-application
status: current
owner: David Rapp
lane: Security_Systems
created: 2026-06-18
tags:
  - job-search
  - application
  - resume
  - security-systems
aliases:
  - Security Systems   Low-Voltage Field Technician
---

# DAVID ANTHONY RAPP - SECURITY SYSTEMS / LOW-VOLTAGE FIELD TECHNICIAN

**Contact:** Cincinnati, OH | 326-201-9245 | rappdavid62@gmail.com

## Use This For
I am applying for security systems, low-voltage, alarm, CCTV, access control, cable/fiber-adjacent, and field technician roles where hands-on troubleshooting, wiring/cabling, customer-site work, reliability, and practical problem solving matter. My background combines security/low-voltage installation support with recent operations, inventory, moving/driving, and customer issue-resolution experience.

## Headline
Security Systems / Low-Voltage Field Technician

## Summary
Hands-on security systems and low-voltage installation technician with practical experience in alarm/security systems, CCTV/cameras, DVRs, motion detectors, smoke detectors, control panels, wire/cable runs, troubleshooting, service calls, customer-site work, supplier coordination, estimates, and field problem solving. Recent operations, inventory, moving/driving, and customer issue-resolution background adds reliability, physical stamina, accuracy, and practical communication.

## Core Skills
- Security systems
- Low-voltage installation
- Alarm panels
- CCTV / cameras
- DVRs
- Motion detectors
- Smoke detectors
- Control panels
- Wire and cable runs
- Troubleshooting
- Service calls
- Customer-site work
- Access control-adjacent work
- Supplier coordination
- Equipment purchasing
- Estimates and proposals
- Inventory control
- Physical labor
- Valid driver's license

## Low-Voltage / Security Installation Support
**Pro-Techs Security / Family Business Background** | Cincinnati / Owensville, OH area | Approx. 2001-2011, intermittent

- Installed, serviced, updated, and troubleshot residential low-voltage and security systems in customer-site environments.
- Ran wire and cable for new installations, repairs, updates, and device connections.
- Programmed alarm/security panels and tested cameras, DVRs, motion detectors, smoke detectors, control panels, sensors, and related equipment.
- Installed cameras/CCTV, DVRs, motion detectors, smoke detectors, control panels, sprinkler systems, central vacuum systems, invisible fences, automatic gates, automatic doors, and related residential systems.
- Supported routine and emergency service calls by diagnosing failures, restoring function, explaining problems to customers, and completing follow-up work.
- Helped with supplier coordination, equipment purchasing, estimates, proposals, customer communication, and job-site problem solving.
## D2C Packing Specialist
**Eleeo** | Cincinnati, OH | Jan. 7, 2025 - Apr. 28, 2026

- Redesigned and reorganized the picking system and inventory layout to improve fulfillment flow, order accuracy, and day-to-day usability.
- Counted, rotated, and organized inventory; handled labels, returns, online orders, picking order printing, and shipping readiness.
- Helped improve workflow quality and reduce error rates by about 60%, contributing to a long-standing 1% error target that had not been reached for roughly two years before arrival.
- Resolved customer complaints and online order issues while maintaining accuracy under time pressure.
- Worked independently and with a team in a fast-moving operations environment with changing priorities.
## Driver / Mover
**Clark And Sons Moving** | Cincinnati, OH | Mar. 8, 2022 - Dec. 12, 2024

- Worked approximately 3 years total, including roughly 1 year as a driver with responsibility for route execution, vehicle use, customer property, and crew support.
- Loaded, unloaded, protected customer property, and handled physically demanding work in homes and businesses.
- Communicated with customers, solved job-site problems, and stayed reliable in route-based, customer-facing physical work.
- Followed instructions, adapted to unclear situations, and helped complete jobs safely and efficiently.



## Education
- **Live Oaks Career Campus** | Milford, OH | Interactive Media Program, completed 2005
- **Amelia High School** | Amelia, OH | High School Diploma, 2005

## Copy-Paste Application Statement
I am applying for security systems, low-voltage, alarm, CCTV, access control, cable/fiber-adjacent, and field technician roles where hands-on troubleshooting, wiring/cabling, customer-site work, reliability, and practical problem solving matter. My background combines security/low-voltage installation support with recent operations, inventory, moving/driving, and customer issue-resolution experience.

## Notes / Guardrails
- Do not invent dates, licenses, tools, or clinical duties.
- Use this version only for roles matching the lane above.
- For Indeed, upload the matching PDF or DOCX and copy the summary/headline into profile fields.
