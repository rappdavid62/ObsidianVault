---
type: job-application
status: current
owner: David Rapp
lane: HVAC_Helper
created: 2026-06-18
tags:
  - job-search
  - application
  - resume
  - hvac-helper
aliases:
  - Hvac Helper   Installation Apprentice   Field Support
---

# DAVID ANTHONY RAPP - HVAC HELPER / INSTALLATION APPRENTICE / FIELD SUPPORT

**Contact:** Cincinnati, OH | 326-201-9245 | rappdavid62@gmail.com

## Use This For
I am applying for HVAC helper, apprentice, installation support, maintenance-helper, and facilities support roles where hands-on work, reliability, following procedures, tools/materials handling, customer-site professionalism, and willingness to learn matter. My background includes prior HVAC installation support, low-voltage/security installation exposure, moving/driving, fulfillment, inventory, and field problem solving.

## Headline
Hvac Helper / Installation Apprentice / Field Support

## Summary
Hands-on field support candidate targeting HVAC helper, apprentice, installer helper, facilities helper, and maintenance-helper roles. Background includes approximately 3 years of prior HVAC installation support experience, security/low-voltage installation support, physically demanding moving/driving work, inventory and fulfillment operations, customer-site communication, troubleshooting, and reliability in practical work environments.

## Core Skills
- HVAC installation support
- Installer helper work
- Tools and materials handling
- Customer-site work
- Physical labor
- Following procedures
- Mechanical aptitude
- Troubleshooting mindset
- Low-voltage/security installation support
- Wire and cable runs
- Inventory control
- Equipment handling
- Route-based work
- Team support
- Reliability
- Valid driver's license

## Driver / Mover
**Clark And Sons Moving** | Cincinnati, OH | Mar. 8, 2022 - Dec. 12, 2024

- Worked approximately 3 years total, including roughly 1 year as a driver with responsibility for route execution, vehicle use, customer property, and crew support.
- Loaded, unloaded, protected customer property, and handled physically demanding work in homes and businesses.
- Communicated with customers, solved job-site problems, and stayed reliable in route-based, customer-facing physical work.
- Followed instructions, adapted to unclear situations, and helped complete jobs safely and efficiently.
## D2C Packing Specialist
**Eleeo** | Cincinnati, OH | Jan. 7, 2025 - Apr. 28, 2026

- Redesigned and reorganized the picking system and inventory layout to improve fulfillment flow, order accuracy, and day-to-day usability.
- Counted, rotated, and organized inventory; handled labels, returns, online orders, picking order printing, and shipping readiness.
- Helped improve workflow quality and reduce error rates by about 60%, contributing to a long-standing 1% error target that had not been reached for roughly two years before arrival.
- Resolved customer complaints and online order issues while maintaining accuracy under time pressure.
- Worked independently and with a team in a fast-moving operations environment with changing priorities.
## Low-Voltage / Security Installation Support
**Pro-Techs Security / Family Business Background** | Cincinnati / Owensville, OH area | Approx. 2001-2011, intermittent

- Installed, serviced, updated, and troubleshot residential low-voltage and security systems in customer-site environments.
- Ran wire and cable for new installations, repairs, updates, and device connections.
- Programmed alarm/security panels and tested cameras, DVRs, motion detectors, smoke detectors, control panels, sensors, and related equipment.
- Installed cameras/CCTV, DVRs, motion detectors, smoke detectors, control panels, sprinkler systems, central vacuum systems, invisible fences, automatic gates, automatic doors, and related residential systems.
- Supported routine and emergency service calls by diagnosing failures, restoring function, explaining problems to customers, and completing follow-up work.
- Helped with supplier coordination, equipment purchasing, estimates, proposals, customer communication, and job-site problem solving.

## Additional HVAC Background
- Prior HVAC installation support experience, approximately 3 years, including helper-level field work, installation support, tools/materials handling, customer-site work, and physical job-site labor.
- Comfortable with hands-on work, following procedures, carrying equipment, working around mechanical systems, and learning trade-specific methods from senior technicians.
- Related background in security/low-voltage installation, moving/driving, fulfillment, inventory, and customer-site problem solving.

## Education
- **Live Oaks Career Campus** | Milford, OH | Interactive Media Program, completed 2005
- **Amelia High School** | Amelia, OH | High School Diploma, 2005

## Copy-Paste Application Statement
I am applying for HVAC helper, apprentice, installation support, maintenance-helper, and facilities support roles where hands-on work, reliability, following procedures, tools/materials handling, customer-site professionalism, and willingness to learn matter. My background includes prior HVAC installation support, low-voltage/security installation exposure, moving/driving, fulfillment, inventory, and field problem solving.

## Notes / Guardrails
- Do not invent dates, licenses, tools, or clinical duties.
- Use this version only for roles matching the lane above.
- For Indeed, upload the matching PDF or DOCX and copy the summary/headline into profile fields.
