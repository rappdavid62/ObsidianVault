---
type: job-application
status: current
owner: David Rapp
lane: PRS
created: 2026-06-18
tags:
  - job-search
  - application
  - resume
  - prs
aliases:
  - Peer Recovery Supporter   Behavioral Health Support
---

# DAVID ANTHONY RAPP - PEER RECOVERY SUPPORTER / BEHAVIORAL HEALTH SUPPORT

**Contact:** Cincinnati, OH | 326-201-9245 | rappdavid62@gmail.com

## Use This For
I am applying for Peer Recovery Supporter and behavioral health support roles where lived-experience-informed support, recovery communication, boundaries, confidentiality, documentation, resource connection, and calm engagement matter. I am an Ohio Certified Peer Recovery Supporter with OhioMHAS training and a practical work background in people-facing, high-stress environments.

## Headline
Peer Recovery Supporter / Behavioral Health Support

## Summary
Ohio Certified Peer Recovery Supporter with OhioMHAS 40-hour training and scope in co-occurring mental health and substance use disorders. Strengths include recovery communication, active listening, client engagement, trauma-informed communication, boundaries, confidentiality, documentation, de-escalation, resource connection, and calm support for people under stress. Background in customer-facing operations, moving/driving, and problem-solving adds reliability and follow-through.

## Core Skills
- Peer recovery support
- Recovery communication
- Lived-experience-informed support
- Active listening
- Client engagement
- De-escalation
- Trauma-informed communication
- Boundaries
- Confidentiality
- Documentation / note-taking
- Community resource connection
- Group support
- Care coordination support
- Customer service
- Working with people under stress
- Reliability
- Valid driver's license

## D2C Packing Specialist
**Eleeo** | Cincinnati, OH | Jan. 7, 2025 - Apr. 28, 2026

- Redesigned and reorganized the picking system and inventory layout to improve fulfillment flow, order accuracy, and day-to-day usability.
- Counted, rotated, and organized inventory; handled labels, returns, online orders, picking order printing, and shipping readiness.
- Helped improve workflow quality and reduce error rates by about 60%, contributing to a long-standing 1% error target that had not been reached for roughly two years before arrival.
- Resolved customer complaints and online order issues while maintaining accuracy under time pressure.
- Worked independently and with a team in a fast-moving operations environment with changing priorities.
## Driver / Mover
**Clark And Sons Moving** | Cincinnati, OH | Mar. 8, 2022 - Dec. 12, 2024

- Worked approximately 3 years total, including roughly 1 year as a driver with responsibility for route execution, vehicle use, customer property, and crew support.
- Loaded, unloaded, protected customer property, and handled physically demanding work in homes and businesses.
- Communicated with customers, solved job-site problems, and stayed reliable in route-based, customer-facing physical work.
- Followed instructions, adapted to unclear situations, and helped complete jobs safely and efficiently.

## Peer Recovery Support Credential
- Ohio Certified Peer Recovery Supporter - License APS.006470
- OhioMHAS 40-hour PRS training - Training ID MON554
- Training completed Apr. 27, 2025
- Scope includes co-occurring mental health and substance use disorders
## Transferable PRS Experience
- Supported people under stress through calm communication, active listening, patience, and follow-through.
- Resolved complaints and unclear problems while staying professional and focused on next steps.
- Maintained boundaries, confidentiality-minded communication, documentation habits, and reliability in customer-facing work.
- Prepared to support recovery planning, resource linkage, advocacy, group support, and peer role-modeling within certified PRS scope.

## Education
- **Live Oaks Career Campus** | Milford, OH | Interactive Media Program, completed 2005
- **Amelia High School** | Amelia, OH | High School Diploma, 2005

## Copy-Paste Application Statement
I am applying for Peer Recovery Supporter and behavioral health support roles where lived-experience-informed support, recovery communication, boundaries, confidentiality, documentation, resource connection, and calm engagement matter. I am an Ohio Certified Peer Recovery Supporter with OhioMHAS training and a practical work background in people-facing, high-stress environments.

## Notes / Guardrails
- Do not invent dates, licenses, tools, or clinical duties.
- Use this version only for roles matching the lane above.
- For Indeed, upload the matching PDF or DOCX and copy the summary/headline into profile fields.
