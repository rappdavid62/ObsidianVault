STATE, NOT FATE — COMPLETE LOCAL TEST KIT

Bottom line:
This is a local-only test package. It does not publish the app online.

Files:
  index.html
  index.css
  app.js
  state-not-fate-standalone-local.html
  START_LOCAL_TEST_WINDOWS.bat
  START_LOCAL_TEST_POWERSHELL.ps1
  index.original-with-google-font-import.css

Recommended testing method:
1. Unzip the package.
2. Double-click START_LOCAL_TEST_WINDOWS.bat.
3. Your browser should open:
   http://localhost:8000
4. Keep the terminal window open while testing.
5. Press Ctrl+C in the terminal when finished.

Simplest testing method:
Double-click state-not-fate-standalone-local.html.
This is the easiest way to test without a local server.

Privacy/offline note:
The active index.css has the Google Fonts @import removed so the app does not automatically contact Google Fonts.
The original CSS is included as index.original-with-google-font-import.css in case you want the exact original styling later.

Data storage:
The app stores data in your browser's localStorage under:
  state_not_fate_state

It does not send app data to a server in the uploaded JavaScript.
Do not use real sensitive data until you are comfortable with localStorage behavior and browser privacy.

Resetting data:
Inside the app, use the reset intake control if available.
Manual reset:
1. Open the app.
2. Press F12.
3. Open Console.
4. Run:
   localStorage.removeItem("state_not_fate_state")
5. Refresh the page.

Known packaging decision:
This kit preserves your uploaded app logic. It does not refactor the app or add a backend.
