Set-Location -Path $PSScriptRoot

Write-Host ""
Write-Host "State, Not Fate - Local Test Server"
Write-Host "-----------------------------------"
Write-Host "This runs on your computer only."
Write-Host "URL: http://localhost:8000"
Write-Host ""
Write-Host "Leave this window open while testing."
Write-Host "Press Ctrl+C to stop the server."
Write-Host ""

foreach ($file in @("index.html", "index.css", "app.js")) {
    if (!(Test-Path ".\$file")) {
        Write-Host "ERROR: $file is missing."
        Read-Host "Press Enter to exit"
        exit 1
    }
}

Start-Process "http://localhost:8000"

if (Get-Command py -ErrorAction SilentlyContinue) {
    py -3 -m http.server 8000
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    python -m http.server 8000
} else {
    Write-Host "ERROR: Python was not found."
    Write-Host "Install Python, or open state-not-fate-standalone-local.html directly."
    Read-Host "Press Enter to exit"
}
