// State, Not Fate Recovery Operating System - Client Logic Engine

const DEFAULT_STATE = {
    isOnboarded: false,
    ratings: {
        sleep: 0,
        morning: 0,
        initiation: 0,
        clutter: 0,
        energy: 0,
        shame: 0,
        hygiene: 0,
        eating: 0,
        social: 0,
        meaning: 0
    },
    safety: {
        suicide: 0,
        psychosis: 0,
        mania: 0
    },
    customMantra: "I am a happy, healthy, handsome, confident, charismatic man, and people like me.",
    negativeBeliefs: "",
    worstTime: "morning",
    stillWorks: "",
    mvd: [
        "Wake on workdays by 7:30am, drink water, take morning medication.",
        "Brush teeth, eat a simple protein block before energy crash.",
        "Stand outside for 2 minutes in daylight, keep tomorrow's clothes pre-positioned."
    ],
    reasonsLive: "",
    safeContacts: "",
    distractions: "",
    linkedFiles: [],
    todayEnergy: "medium", // default morning check-in state
    mantraCompletedToday: false,
    history: [], // { date: "YYYY-MM-DD", energy: "...", completed: [], floorCompleted: bool, mvdCompleted: bool, missed: bool }
    currentHopeLevel: 1,
    hopeProgress: 0,
    dominantPattern: "Rhythm Collapse"
};

let state = { ...DEFAULT_STATE };

// Document Elements
const screens = {
    welcome: document.getElementById("screen-welcome"),
    intake: document.getElementById("screen-intake"),
    dashboard: document.getElementById("screen-dashboard")
};

const tabs = {
    dashboard: document.getElementById("tab-dashboard"),
    safebox: document.getElementById("tab-safebox"),
    explorer: document.getElementById("tab-explorer")
};

// Initial Load & State Synchronization
function init() {
    loadState();
    setupEventListeners();
    
    if (state.isOnboarded) {
        showScreen("dashboard");
        renderDashboard();
    } else {
        showScreen("welcome");
    }
}

function loadState() {
    const saved = localStorage.getItem("state_not_fate_state");
    if (saved) {
        try {
            state = JSON.parse(saved);
            // Fallback for default values if missing
            if (!state.mvd || state.mvd.length === 0) state.mvd = [ ...DEFAULT_STATE.mvd ];
            if (state.linkedFiles === undefined) state.linkedFiles = [];
        } catch (e) {
            console.error("Error reading saved state, resetting...", e);
            state = { ...DEFAULT_STATE };
        }
    }
}

function saveState() {
    localStorage.setItem("state_not_fate_state", JSON.stringify(state));
}

function showScreen(screenId) {
    Object.keys(screens).forEach(key => {
        if (key === screenId) {
            screens[key].classList.remove("hidden");
        } else {
            screens[key].classList.add("hidden");
        }
    });
}

function showTab(tabId) {
    Object.keys(tabs).forEach(key => {
        if (key === tabId) {
            tabs[key].classList.remove("hidden");
        } else {
            tabs[key].classList.add("hidden");
        }
    });
    
    // Update active tab button style
    document.querySelectorAll(".tab-btn").forEach(btn => {
        if (btn.getAttribute("data-tab") === tabId) {
            btn.classList.add("active");
        } else {
            btn.classList.remove("active");
        }
    });
}

// Onboarding Navigation & Accordion Toggles
function setupEventListeners() {
    // Welcome Buttons
    document.getElementById("btn-start-intake").addEventListener("click", () => {
        showScreen("intake");
        initIntakeForm();
    });

    document.getElementById("btn-back-welcome").addEventListener("click", () => {
        showScreen("welcome");
    });

    // Onboarding Accordion headers
    document.querySelectorAll(".accordion-header").forEach(header => {
        header.addEventListener("click", (e) => {
            const currentSection = e.target.closest(".accordion-section");
            const isActive = currentSection.classList.contains("active");
            
            // Collapse all
            document.querySelectorAll(".accordion-section").forEach(sec => sec.classList.remove("active"));
            
            if (!isActive) {
                currentSection.classList.add("active");
            }
        });
    });

    // Rating Buttons click handlers
    document.querySelectorAll(".rating-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const container = e.target.parentElement;
            const metric = container.getAttribute("data-metric");
            const val = parseInt(e.target.getAttribute("data-val"));
            
            // Deselect siblings
            container.querySelectorAll(".rating-btn").forEach(b => b.classList.remove("selected"));
            e.target.classList.add("selected");
            
            state.ratings[metric] = val;
        });
    });

    // Safety Screening button click handlers
    document.querySelectorAll(".safety-option-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const row = e.target.closest(".safety-row");
            const safetyType = row.getAttribute("data-safety-type");
            const val = parseInt(e.target.getAttribute("data-val"));
            
            row.querySelectorAll(".safety-option-btn").forEach(b => b.classList.remove("selected"));
            e.target.classList.add("selected");
            
            state.safety[safetyType] = val;
        });
    });

    // Submit Intake
    document.getElementById("btn-submit-intake").addEventListener("click", submitIntake);

    // Tab Navigation Switchers
    document.querySelectorAll(".tab-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const tabId = e.target.getAttribute("data-tab");
            if (tabId === "reset-intake") {
                if (confirm("Are you sure you want to reset your intake data? This will clear your current dashboard progress.")) {
                    resetToOnboarding();
                }
            } else {
                showTab(tabId);
                if (tabId === "safebox") {
                    renderSafeBox();
                    // If high risk is active, trigger warning bridge overlay
                    if (isHighRiskActive()) {
                        triggerCrisisOverlay();
                    }
                }
            }
        });
    });

    // Morning Energy Selector check-in click handlers
    document.querySelectorAll(".energy-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const energyBtn = e.target.closest(".energy-btn");
            const energyVal = energyBtn.getAttribute("data-energy");
            
            document.querySelectorAll(".energy-btn").forEach(b => b.classList.remove("active"));
            energyBtn.classList.add("active");
            
            state.todayEnergy = energyVal;
            
            // Check if in collapse mode
            if (energyVal === "collapse") {
                logMissInHistory();
            }
            
            saveState();
            renderDailyChecklist();
            updateDashboardMetrics();
        });
    });

    // Mantra complete buttons
    document.getElementById("btn-check-mantra").addEventListener("click", () => {
        state.mantraCompletedToday = true;
        document.getElementById("btn-check-mantra").innerHTML = "✓ Active Identity Anchored";
        document.getElementById("btn-check-mantra").disabled = true;
        logActionCompletion("Master Counter-Script Recited Aloud");
        saveState();
        updateDashboardMetrics();
    });

    // Safe box File Linking button
    document.getElementById("btn-add-file-link").addEventListener("click", addFileLink);

    // Modal close buttons
    document.getElementById("btn-close-crisis-modal").addEventListener("click", () => {
        document.getElementById("crisis-modal").classList.remove("active");
    });
    document.getElementById("btn-crisis-dismiss").addEventListener("click", () => {
        document.getElementById("crisis-modal").classList.remove("active");
    });
    document.getElementById("btn-crisis-go-safebox").addEventListener("click", () => {
        document.getElementById("crisis-modal").classList.remove("active");
        showTab("safebox");
        renderSafeBox();
    });

    // Breathing guide triggers
    document.getElementById("btn-trigger-breathe").addEventListener("click", triggerBreathingModal);
    document.getElementById("btn-close-breath-modal").addEventListener("click", closeBreathingModal);
    document.getElementById("btn-breath-done").addEventListener("click", () => {
        closeBreathingModal();
        document.getElementById("btn-check-mantra").click(); // mark as checked
    });
}

// Initialize form states
function initIntakeForm() {
    // Populate form elements from state in case of partial fills
    document.getElementById("input-custom-mantra").value = state.customMantra;
    document.getElementById("input-negative-beliefs").value = state.negativeBeliefs;
    document.getElementById("select-worst-time").value = state.worstTime;
    document.getElementById("input-still-works").value = state.stillWorks;
    document.getElementById("input-mvd-1").value = state.mvd[0];
    document.getElementById("input-mvd-2").value = state.mvd[1];
    document.getElementById("input-mvd-3").value = state.mvd[2];
    document.getElementById("input-reasons-live").value = state.reasonsLive;
    document.getElementById("input-safe-contacts").value = state.safeContacts;
    document.getElementById("input-distraction-activities").value = state.distractions;
    
    // Set active accordion section
    document.querySelectorAll(".accordion-section").forEach((sec, idx) => {
        if (idx === 0) sec.classList.add("active");
        else sec.classList.remove("active");
    });
}

// Submit Assessment & Calculate Scoring Profile
function submitIntake() {
    // Compile inputs
    state.customMantra = document.getElementById("input-custom-mantra").value.trim() || DEFAULT_STATE.customMantra;
    state.negativeBeliefs = document.getElementById("input-negative-beliefs").value.trim();
    state.worstTime = document.getElementById("select-worst-time").value;
    state.stillWorks = document.getElementById("input-still-works").value.trim();
    
    state.mvd = [
        document.getElementById("input-mvd-1").value.trim() || DEFAULT_STATE.mvd[0],
        document.getElementById("input-mvd-2").value.trim() || DEFAULT_STATE.mvd[1],
        document.getElementById("input-mvd-3").value.trim() || DEFAULT_STATE.mvd[2]
    ];
    
    state.reasonsLive = document.getElementById("input-reasons-live").value.trim();
    state.safeContacts = document.getElementById("input-safe-contacts").value.trim();
    state.distractions = document.getElementById("input-distraction-activities").value.trim();
    
    // Scoring Logic (Rule 4: Match to Pattern)
    state.dominantPattern = calculatePrimaryPattern();
    state.isOnboarded = true;
    state.todayEnergy = "medium"; // set starting day to medium
    
    saveState();
    showScreen("dashboard");
    showTab("dashboard");
    renderDashboard();
    
    // Check if screening flags active crisis
    if (isHighRiskActive()) {
        triggerCrisisOverlay();
    }
}

function calculatePrimaryPattern() {
    const r = state.ratings;
    const scores = {
        "Rhythm Collapse": (r.sleep || 0) + (r.morning || 0),
        "Environmental Drag": (r.clutter || 0) * 2, // weight heavy clutter
        "Total Initiation Failure": (r.initiation || 0) * 2,
        "High Shame / Low Trust": (r.shame || 0) + (r.meaning || 0),
        "Fragile Consistency": (r.shame || 0) + (r.initiation || 0),
        "Good-Day Overreach": (r.shame || 0) + (r.energy || 0)
    };
    
    let bestPattern = "Rhythm Collapse";
    let maxScore = -1;
    
    Object.keys(scores).forEach(pattern => {
        if (scores[pattern] > maxScore) {
            maxScore = scores[pattern];
            bestPattern = pattern;
        }
    });
    
    return bestPattern;
}

function isHighRiskActive() {
    return state.safety.suicide === 2 || state.safety.psychosis === 2 || state.safety.mania === 2;
}

function triggerCrisisOverlay() {
    document.getElementById("crisis-modal").classList.add("active");
}

function resetToOnboarding() {
    localStorage.removeItem("state_not_fate_state");
    state = { ...DEFAULT_STATE };
    showScreen("welcome");
}

// Render Dashboard Functions
function renderDashboard() {
    // 1. Render Master Mantra Card
    document.getElementById("dashboard-mantra-text").innerHTML = `"${state.customMantra}"`;
    
    // Reset mantra button state
    state.mantraCompletedToday = isMantraCompletedToday();
    const mantraBtn = document.getElementById("btn-check-mantra");
    if (state.mantraCompletedToday) {
        mantraBtn.innerHTML = "✓ Active Identity Anchored";
        mantraBtn.disabled = true;
    } else {
        mantraBtn.innerHTML = "✓ Repeated Aloud";
        mantraBtn.disabled = false;
    }
    
    // 2. Set Active Energy check-in buttons
    document.querySelectorAll(".energy-btn").forEach(btn => {
        if (btn.getAttribute("data-energy") === state.todayEnergy) {
            btn.classList.add("active");
        } else {
            btn.classList.remove("active");
        }
    });
    
    // 3. Render Checklist
    renderDailyChecklist();
    
    // 4. Update metrics & analytics
    updateDashboardMetrics();
}

function isMantraCompletedToday() {
    const today = getTodayString();
    const todayLog = state.history.find(log => log.date === today);
    return todayLog ? todayLog.completed.includes("Master Counter-Script Recited Aloud") : false;
}

function getTodayString() {
    const d = new Date();
    // Offset local timezone date cleanly
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

// Generate the Dynamic Action List based on Pattern & Energy State
function renderDailyChecklist() {
    const container = document.getElementById("daily-checklist-items");
    container.innerHTML = "";
    
    const energy = state.todayEnergy;
    const badge = document.getElementById("active-energy-badge");
    const warning = document.getElementById("collapse-warning-banner");
    
    // Update badge styling
    badge.className = `badge badge-${energy}`;
    badge.innerHTML = `${energy.toUpperCase()} ENERGY`;
    
    if (energy === "collapse") {
        warning.classList.remove("hidden");
    } else {
        warning.classList.add("hidden");
    }
    
    // Compile active tasks array
    let tasks = [];
    
    // Under Low/Collapse, show STRICTLY the Floor/MVD anchors to prevent overload
    if (energy === "collapse" || energy === "low") {
        tasks = [
            { label: state.mvd[0], isMvd: true },
            { label: state.mvd[1], isMvd: true },
            { label: state.mvd[2], isMvd: true }
        ];
    } else {
        // Medium / High states include both MVD floor and Pattern-based anchors
        tasks = [
            { label: state.mvd[0], isMvd: true },
            { label: state.mvd[1], isMvd: true },
            { label: state.mvd[2], isMvd: true }
        ];
        
        // Inject core biological anchors
        tasks.push({ label: "Morning outdoor light exposure (10 minutes circadian signal)", isMvd: false });
        tasks.push({ label: "Medication adherence checklist item (substrate floor)", isMvd: false });
        
        // Inject Pattern specific anchors
        if (state.dominantPattern === "Rhythm Collapse") {
            tasks.push({ label: "Maintain precise pre-decided workday sleep/wake anchors", isMvd: false });
            tasks.push({ label: "Execute immediate first-hour actions without debate", isMvd: false });
        } else if (state.dominantPattern === "Environmental Drag") {
            tasks.push({ label: "Clear and reset 1 visible surface zone (anti-chaos)", isMvd: false });
            tasks.push({ label: "Perform a focused 10-minute trash removal swipe", isMvd: false });
        } else if (state.dominantPattern === "Total Initiation Failure") {
            tasks.push({ label: "Execute 1 micro-threshold task (define first 10 seconds only)", isMvd: false });
            tasks.push({ label: "Pre-position tomorrow's work clothes and tools by the door", isMvd: false });
        } else if (state.dominantPattern === "High Shame / Low Trust") {
            tasks.push({ label: "Maintain small base wins only; strictly avoid grand plans", isMvd: false });
            tasks.push({ label: "Send 1 low-threat connection text ('Thinking of you, no pressure')", isMvd: false });
        } else if (state.dominantPattern === "Fragile Consistency" || state.dominantPattern === "Good-Day Overreach") {
            tasks.push({ label: "Cap today's ambition floor; prevent good-day overreach burnout", isMvd: false });
            tasks.push({ label: "Execute 5-minute graded body movement (no identity gym targets)", isMvd: false });
        }
        
        // High energy expansion anchors
        if (energy === "high") {
            tasks.push({ label: "Complete structured 10-minute walking, yoga, or light exercise", isMvd: false });
            tasks.push({ label: "Structured meditation session (10 to 15 minutes focus gap)", isMvd: false });
            tasks.push({ label: "Handle 1 admin micro-task (open mail, file one document, pay one bill)", isMvd: false });
        }
    }
    
    // Get currently checked items from today's history log
    const today = getTodayString();
    const todayLog = state.history.find(log => log.date === today);
    const completedList = todayLog ? todayLog.completed : [];
    
    // Inject checklist HTML
    tasks.forEach(task => {
        const item = document.createElement("div");
        const isChecked = completedList.includes(task.label);
        
        item.className = `task-item ${isChecked ? 'checked' : ''}`;
        item.innerHTML = `
            <div class="task-checkbox"></div>
            <div class="task-label">${task.label}</div>
        `;
        
        item.addEventListener("click", () => {
            toggleTask(task.label, item);
        });
        
        container.appendChild(item);
    });
}

function toggleTask(label, element) {
    const today = getTodayString();
    let todayLog = state.history.find(log => log.date === today);
    
    if (!todayLog) {
        todayLog = {
            date: today,
            energy: state.todayEnergy,
            completed: [],
            floorCompleted: false,
            mvdCompleted: false,
            missed: false
        };
        state.history.push(todayLog);
    }
    
    const index = todayLog.completed.indexOf(label);
    let isNowChecked = false;
    
    if (index === -1) {
        todayLog.completed.push(label);
        element.classList.add("checked");
        isNowChecked = true;
    } else {
        todayLog.completed.splice(index, 1);
        element.classList.remove("checked");
    }
    
    // Assess if floor / MVD completed
    evaluateDaySuccess(todayLog);
    saveState();
    updateDashboardMetrics();
}

function logActionCompletion(label) {
    const today = getTodayString();
    let todayLog = state.history.find(log => log.date === today);
    
    if (!todayLog) {
        todayLog = {
            date: today,
            energy: state.todayEnergy,
            completed: [],
            floorCompleted: false,
            mvdCompleted: false,
            missed: false
        };
        state.history.push(todayLog);
    }
    
    if (!todayLog.completed.includes(label)) {
        todayLog.completed.push(label);
    }
    
    evaluateDaySuccess(todayLog);
}

function logMissInHistory() {
    const today = getTodayString();
    let todayLog = state.history.find(log => log.date === today);
    
    if (!todayLog) {
        todayLog = {
            date: today,
            energy: state.todayEnergy,
            completed: [],
            floorCompleted: false,
            mvdCompleted: false,
            missed: true
        };
        state.history.push(todayLog);
    } else {
        todayLog.energy = "collapse";
        evaluateDaySuccess(todayLog);
    }
}

// Evaluate daily completeness (MVD vs Floor)
function evaluateDaySuccess(todayLog) {
    // MVD tasks required
    const mvdCompleted = state.mvd.every(task => todayLog.completed.includes(task));
    
    // Check if daily standard is complete relative to current energy state
    const energy = todayLog.energy;
    
    todayLog.mvdCompleted = mvdCompleted;
    
    if (energy === "collapse" || energy === "low") {
        todayLog.floorCompleted = mvdCompleted;
        todayLog.missed = !mvdCompleted;
    } else {
        // Medium / High requires more than just MVD to mark floor as fully successful
        const totalCompleted = todayLog.completed.length;
        const requiredCompleted = energy === "high" ? 6 : 4;
        
        todayLog.floorCompleted = mvdCompleted && (totalCompleted >= requiredCompleted);
        todayLog.missed = !mvdCompleted;
    }
}

// Calculate and Update Dash Metrics (Resilience & Hope levels)
function updateDashboardMetrics() {
    const totalFloorDays = state.history.filter(log => log.floorCompleted).length;
    
    // Calculate Resilience Rate
    const statsResilience = calculateResilienceRate();
    document.getElementById("stats-resilience-rate").innerHTML = `${statsResilience}%`;
    document.getElementById("stats-floor-days").innerHTML = totalFloorDays;
    
    // Calculate Hope progression levels
    updateHopeLevel(totalFloorDays);
}

function calculateResilienceRate() {
    const h = state.history;
    if (h.length === 0) return 100;
    
    let totalMisses = 0;
    let successfulRestarts = 0;
    
    for (let i = 0; i < h.length; i++) {
        if (h[i].missed) {
            totalMisses++;
            // Check next day (i + 1)
            if (i + 1 < h.length) {
                if (h[i + 1].floorCompleted || h[i + 1].mvdCompleted) {
                    successfulRestarts++;
                }
            }
        }
    }
    
    if (totalMisses === 0) return 100;
    return Math.round((successfulRestarts / totalMisses) * 100);
}

function updateHopeLevel(totalFloorDays) {
    const fill = document.getElementById("hope-bar-fill");
    const lvlText = document.getElementById("label-hope-level");
    const lvlPercent = document.getElementById("label-hope-percent");
    const title = document.getElementById("hope-level-title");
    const desc = document.getElementById("hope-level-desc");
    
    let level = 1;
    let progress = 0;
    let lTitle = "Action is Possible";
    let lDesc = "Rebuild self-trust. Complete small daily anchors to register proof.";
    
    // Graded Hope levels mapping (proof-based)
    if (totalFloorDays < 3) {
        level = 1;
        progress = (totalFloorDays / 3) * 20;
    } else if (totalFloorDays < 7) {
        level = 2;
        progress = 20 + ((totalFloorDays - 3) / 4) * 20;
        lTitle = "Action Causes Results";
        lDesc = "Your actions are creating observable outcomes. The floor is stabilizing.";
    } else if (totalFloorDays < 12) {
        level = 3;
        progress = 40 + ((totalFloorDays - 7) / 5) * 20;
        lTitle = "The Result Can Repeat";
        lDesc = "Repetition builds neuroplasticity. You are proving you can restart repeatedly.";
    } else if (totalFloorDays < 20) {
        level = 4;
        progress = 60 + ((totalFloorDays - 12) / 8) * 20;
        lTitle = "Repetition Stabilizes Life";
        lDesc = "Mornings, hygiene, and routines are losing their chaos. The floor is solid.";
    } else {
        level = 5;
        progress = Math.min(100, 80 + ((totalFloorDays - 20) / 10) * 20);
        lTitle = "Stability Supports a Future";
        lDesc = "A wider future is thinkable. Safe re-expansion into work and social connection.";
    }
    
    state.currentHopeLevel = level;
    state.hopeProgress = Math.round(progress);
    
    fill.style.width = `${progress}%`;
    lvlText.innerHTML = `Level ${level}`;
    lvlPercent.innerHTML = `${Math.round(progress)}%`;
    title.innerHTML = lTitle;
    desc.innerHTML = lDesc;
}

// Render Crisis Safe Box Tab
function renderSafeBox() {
    document.getElementById("display-reasons-live").innerHTML = state.reasonsLive || "No reasons added yet. Edit in Intake to add anchors.";
    document.getElementById("display-distraction-activities").innerHTML = state.distractions || "No coping activities listed yet.";
    document.getElementById("display-safe-contacts").innerHTML = state.safeContacts || "No emergency contacts listed yet.";
    
    renderLinkedFilesList();
}

function renderLinkedFilesList() {
    const container = document.getElementById("linked-files-container");
    container.innerHTML = "";
    
    if (state.linkedFiles.length === 0) {
        container.innerHTML = `<div class="text-muted center-text py-2" style="font-size:0.85rem;">No personal files logged yet. Log your path below.</div>`;
        return;
    }
    
    state.linkedFiles.forEach((file, index) => {
        const item = document.createElement("div");
        item.className = "linked-file-item";
        item.innerHTML = `
            <div class="linked-file-info">
                <div class="linked-file-name">${file.name}</div>
                <div class="linked-file-path">${file.path}</div>
            </div>
            <div style="display:flex; gap:0.5rem; align-items:center;">
                <button class="btn btn-secondary" onclick="navigator.clipboard.writeText('${file.path.replace(/\\/g, '\\\\')}'); alert('Path copied to clipboard!')" style="padding:0.4rem 0.6rem; font-size:0.75rem;">Copy Path</button>
                <button class="linked-file-remove" data-idx="${index}">×</button>
            </div>
        `;
        
        item.querySelector(".linked-file-remove").addEventListener("click", () => {
            removeFileLink(index);
        });
        
        container.appendChild(item);
    });
}

function addFileLink() {
    const nameInput = document.getElementById("input-link-filename");
    const pathInput = document.getElementById("input-link-path");
    
    const name = nameInput.value.trim();
    const path = pathInput.value.trim();
    
    if (!name || !path) {
        alert("Please enter both the file label and its local absolute system path.");
        return;
    }
    
    state.linkedFiles.push({ name, path });
    saveState();
    renderLinkedFilesList();
    
    nameInput.value = "";
    pathInput.value = "";
}

function removeFileLink(index) {
    state.linkedFiles.splice(index, 1);
    saveState();
    renderLinkedFilesList();
}

// Mantra Pacer & Breathing Guide Modal Engine
let breatheInterval = null;
function triggerBreathingModal() {
    const modal = document.getElementById("breath-modal");
    const subtitle = document.getElementById("breath-mantra-subtitle");
    const pacer = document.getElementById("pacer-circle");
    const phaseText = document.getElementById("breath-phase-text");
    
    subtitle.innerHTML = `"${state.customMantra}"`;
    modal.classList.add("active");
    
    // Simple 4-second breathing pace trigger
    let phase = 0; // 0=inhale, 1=hold, 2=exhale, 3=hold
    phaseText.innerHTML = "Inhale...";
    pacer.style.transform = "scale(1.5)";
    
    breatheInterval = setInterval(() => {
        phase = (phase + 1) % 4;
        if (phase === 0) {
            phaseText.innerHTML = "Inhale...";
            pacer.style.transform = "scale(1.5)";
        } else if (phase === 1) {
            phaseText.innerHTML = "Hold...";
        } else if (phase === 2) {
            phaseText.innerHTML = "Exhale (Repeat Mantra aloud)...";
            pacer.style.transform = "scale(1.0)";
        } else if (phase === 3) {
            phaseText.innerHTML = "Hold...";
        }
    }, 4000);
}

function closeBreathingModal() {
    document.getElementById("breath-modal").classList.remove("active");
    if (breatheInterval) {
        clearInterval(breatheInterval);
        breatheInterval = null;
    }
}

// Window Onload Trigger
window.onload = init;
