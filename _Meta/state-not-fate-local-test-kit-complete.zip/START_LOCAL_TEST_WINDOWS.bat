@echo off
setlocal
title State Not Fate - Local Test Server

echo.
echo State, Not Fate - Local Test Server
echo -----------------------------------
echo This runs on your computer only.
echo URL: http://localhost:8000
echo.
echo Leave this window open while testing.
echo Press Ctrl+C to stop the server.
echo.

cd /d "%~dp0"

if not exist "index.html" (
  echo ERROR: index.html is missing.
  pause
  exit /b 1
)
if not exist "index.css" (
  echo ERROR: index.css is missing.
  pause
  exit /b 1
)
if not exist "app.js" (
  echo ERROR: app.js is missing.
  pause
  exit /b 1
)

start "" "http://localhost:8000"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m http.server 8000
  goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
  python -m http.server 8000
  goto :end
)

echo ERROR: Python was not found.
echo Install Python, or open state-not-fate-standalone-local.html directly.
pause

:end
endlocal
